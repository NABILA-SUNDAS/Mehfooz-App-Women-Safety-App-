package com.example.mehfooz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageButton;

public class home extends AppCompatActivity {

    private static final String CHANNEL_ID = "emergency_channel";
    private static final int NOTIFICATION_ID = 1;
    private MediaPlayer mediaPlayer;
    private Handler handler = new Handler();
    private boolean isSirenPlaying = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Find the SOS button by its ID
        ImageButton sosButton = findViewById(R.id.sosbtn);

        // Set a click listener for the SOS button
        sosButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isSirenPlaying) {
                    // Play police alarm sound
                    playPoliceAlarmSound();
                    isSirenPlaying = true;

                    // Show emergency notification
                    showEmergencyNotification();

                    // Stop the police alarm sound after 60 seconds (60000 milliseconds)
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            stopPoliceAlarmSound();
                            isSirenPlaying = false;
                        }
                    }, 60000); // 60 seconds delay
                }
            }
        });

        // Create the notification channel
        createNotificationChannel();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            channel.enableLights(true);
            channel.setLightColor(Color.RED);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    private void showEmergencyNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.mehfoozlogo)
                .setContentTitle("Emergency Notification")
                .setContentText("Notification sent to police")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // Handle permission if needed
            return;
        }
        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }

    private void playPoliceAlarmSound() {
        // Initialize MediaPlayer with police alarm sound from raw resources
        mediaPlayer = MediaPlayer.create(this, R.raw.siren);

        // Set looping to true for continuous playback until stopped
        mediaPlayer.setLooping(true);

        // Start playing the police alarm sound
        mediaPlayer.start();
    }

    private void stopPoliceAlarmSound() {
        // Stop and release MediaPlayer resources
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Release MediaPlayer resources when the activity is stopped
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
        // Remove any pending delayed actions from the handler
        handler.removeCallbacksAndMessages(null);
        isSirenPlaying = false;
    }
}
