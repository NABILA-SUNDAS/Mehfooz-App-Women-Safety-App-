package com.example.mehfooz;



import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class register extends AppCompatActivity {

    private EditText nameEditText, emailEditText, passwordEditText;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        sharedPreferences = getSharedPreferences("loginPrefs", MODE_PRIVATE);

        nameEditText = findViewById(R.id.register_name);
        emailEditText = findViewById(R.id.register_email);
        passwordEditText = findViewById(R.id.register_password);

        Button registerLoginButton = findViewById(R.id.register_login);
        registerLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to LoginActivity
                startActivity(new Intent(register.this, MainActivity.class));
            }
        });

        Button registerButton = findViewById(R.id.register);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredName = nameEditText.getText().toString().trim();
                String enteredEmail = emailEditText.getText().toString().trim();
                String enteredPassword = passwordEditText.getText().toString().trim();

                // Validate input fields
                if (TextUtils.isEmpty(enteredName) || TextUtils.isEmpty(enteredEmail) || TextUtils.isEmpty(enteredPassword)) {
                    // Display error message if any field is empty
                    Toast.makeText(register.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return; // Exit onClick method early
                }

                // Add your registration logic here (e.g., storing user details)
                // For now, we just set the login status to true in shared preferences
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean("isLoggedIn", true);
                editor.apply();

                // Display success message
                Toast.makeText(register.this, "Registration Successful", Toast.LENGTH_SHORT).show();

                // After registration, you can navigate to another activity (e.g., HomeActivity)
                // Example: startActivity(new Intent(RegistrationActivity.this, HomeActivity.class));
                // You should replace HomeActivity with your actual home activity class.
            }
        });
    }
}
