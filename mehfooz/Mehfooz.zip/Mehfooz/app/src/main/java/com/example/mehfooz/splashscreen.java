package com.example.mehfooz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

public class splashscreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);

        // Delay for 3000 milliseconds (3 seconds) before starting MainActivity
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                // Create an Intent to start MainActivity
                Intent intent = new Intent(splashscreen.this, nofearbutton.class);
                startActivity(intent);

                // Finish the current activity (splashscreen) to prevent going back to it
                finish();
            }
        }, 3000); // Delay of 3000 milliseconds (3 seconds)
    }
}
